#!/bin/sh

git config core.hooksPath .githooks
