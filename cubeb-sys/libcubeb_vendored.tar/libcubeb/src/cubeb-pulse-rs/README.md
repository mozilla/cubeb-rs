# cubeb-pulse-rs

Implementation of PulseAudio backend for Cubeb written in Rust.

[![Build Status](https://github.com/mozilla/cubeb-pulse-rs/actions/workflows/build.yml/badge.svg)](https://github.com/mozilla/cubeb-pulse-rs/actions/workflows/build.yml)
